var bg, bgImg;
var bottomGround;
var topGround;
var balloon, balloonImg;
var obstaculo;
var obsBalao, obsPassaro;
var obstaculoDeCima;
var bottom1Img,bottom2Img,bottom3Img;
var restartImg,fimdejogoImg;
var restart,fimdejogo;
var PLAY = 1;
var END = 0;
var EstadoDoJogo = PLAY;
var grupoDeObs = new Group();
var grupoDeObsDeCima = new Group();
var grupoDeBordas = new Group();

function preload(){
bgImg = loadImage("assets/bg.png")

balloonImg = loadAnimation("assets/balloon1.png","assets/balloon2.png","assets/balloon3.png")

obsBalao = loadImage("assets/obsTop1.png");
obsPassaro = loadImage("assets/obsTop2.png");

bottom1Img = loadImage("assets/obsBottom1.png");
bottom2Img = loadImage("assets/obsBottom2.png");
bottom3Img = loadImage("assets/obsBottom3.png");

restartImg = loadImage("assets/restart.png");
fimdejogoImg = loadImage("assets/fimdejogo.png");
}

function setup(){
 bg = createSprite(165,485,1,1);
 bg.addImage(bgImg);
 bg.scale = 1.3;

 bottomGround = createSprite(200,390,800,20);
 bottomGround.visible = true;
 topGround = createSprite(200,10,800,20);
 topGround.visible = true;

 balloon = createSprite(100,200,20,50);
 balloon.addAnimation("balloon", balloonImg);
 balloon.scale = 0.3;

 restart = createSprite(220,240);
 fimdejogo = createSprite(220,200);
 restart.addImage(restartImg);
 fimdejogo.addImage(fimdejogoImg);
 restart.scale = 0.5;
 fimdejogo.scale = 0.5;
 restart.visible = false;
 fimdejogo.visible = false;

}

function draw() {
  
  background("black");

  if(EstadoDoJogo === PLAY){
 
  if(keyDown("space")){
    balloon.velocityY =-6;
  }

  balloon.velocityY = balloon.velocityY + 1;
  obstaculos();
  obstaculosDeCima();
  bar();

  if(grupoDeObs.isTouching(balloon) ||
  grupoDeObsDeCima.isTouching(balloon)||
  balloon.isTouching(topGround)||
  balloon.isTouching(bottomGround)){
    EstadoDoJogo = END;
  }
}
  if(EstadoDoJogo === END){
    fimdejogo.visible = true;
    restart.visible = true;
    fimdejogo.depth += 1;
    restart.depth += 1;

    grupoDeObs.setVelocityXEach(0);
    grupoDeObsDeCima.setVelocityXEach(0);
    grupoDeBordas.setVelocityXEach(0);
    balloon.velocityY = 0;
    balloon.velocityX = 0;
    balloon.y = 200;
  }
        drawSprites();
}

function obstaculos(){
  if(frameCount % 50 === 0){
   obstaculo = createSprite(400,50,40,50);
   obstaculo.velocityX = -4;
   obstaculo.scale = 0.1;
   obstaculo.y = Math.round(random(10,100));
   
   var obsImagem = Math.round(random(1,2));
   switch(obsImagem){
    case 1:
      obstaculo.addImage(obsBalao);
      break;
    case 2:
      obstaculo.addImage(obsPassaro);
      break;
    default:break;
   }

   obstaculo.lifetime = 400/4;
   balloon.depth += 1;
   grupoDeObs.add(obstaculo);

  }
}
  function obstaculosDeCima(){
    if(frameCount % 60 === 0){
      obstaculoDeCima = createSprite(400,350,40,50);
      obstaculoDeCima.velocityX = -3;
      obstaculoDeCima.scale = 0.07;
      
      var obsDeCimaImg = Math.round(random(1,3));
      switch(obsDeCimaImg){
        case 1:
          obstaculoDeCima.addImage(bottom1Img);
          break;
        case 2:
          obstaculoDeCima.addImage(bottom2Img);
          break;
        case 3:
          obstaculoDeCima.addImage(bottom3Img);
          break;
        default:break;
      }

      obstaculoDeCima.lifetime = 400/3;
      balloon.depth += 1;
      grupoDeObsDeCima.add(obstaculoDeCima);
    }
  }
  function bar(){
    if(frameCount % 50 === 0){
    var barra = createSprite(400,200,10,800);
    barra.velocityX = -6;
    barra.lifetime = 70;
    barra.visible = true;
    barra.depth = balloon.depth;
    grupoDeBordas.add(barra);
    } 
  }